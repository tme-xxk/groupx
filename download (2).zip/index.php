<?php
session_start();

$msg = "";
$newLink = "";

// 🔥 session message handle
if(isset($_SESSION['msg'])){
    $msg = $_SESSION['msg'];
    unset($_SESSION['msg']);
}

if(isset($_SESSION['newLink'])){
    $newLink = $_SESSION['newLink'];
    unset($_SESSION['newLink']);
}

// 🔥 random slug
function randomSlug($length = 6){
    $chars = 'abcdefghijklmnopqrstuvwxyz';
    $slug = '';
    for($i=0;$i<$length;$i++){
        $slug .= $chars[rand(0, strlen($chars)-1)];
    }
    return $slug;
}

// files
$files = glob("*.html");
$count = count($files);

// ================= UPLOAD =================
if(isset($_POST['upload'])){
    $ext = strtolower(pathinfo($_FILES['file']['name'], PATHINFO_EXTENSION));

    if($ext != "html"){
        $_SESSION['msg'] = "❌ Only HTML allowed!";
    } else {

        do{
            $slug = randomSlug(6);
        }while(file_exists($slug.".html"));

        if(move_uploaded_file($_FILES['file']['tmp_name'], $slug.".html")){
            $_SESSION['msg'] = "✅ Uploaded!";
            $_SESSION['newLink'] = "https://".$_SERVER['HTTP_HOST']."/".$slug;
        } else {
            $_SESSION['msg'] = "❌ Upload Failed!";
        }
    }

    header("Location: index.php");
    exit;
}

// ================= DELETE =================
if(isset($_POST['delete'])){
    $code = $_POST['code'];

    if(file_exists($code.".html")){
        unlink($code.".html");
        $_SESSION['msg'] = "🗑 Deleted!";
    }

    header("Location: index.php");
    exit;
}

// ================= UPDATE =================
if(isset($_POST['update'])){
    $code = $_POST['code'];

    move_uploaded_file($_FILES['file']['tmp_name'], $code.".html");
    $_SESSION['msg'] = "♻️ Updated!";

    header("Location: index.php");
    exit;
}

// ================= BULK DELETE =================
if(isset($_POST['bulk_update'])){
    if(isset($_POST['codes']) && isset($_FILES['bulk_file'])){
        
        $tmp = $_FILES['bulk_file']['tmp_name'];
        $ext = strtolower(pathinfo($_FILES['bulk_file']['name'], PATHINFO_EXTENSION));

        if($ext != "html"){
            $_SESSION['msg'] = "❌ Only HTML allowed!";
        } else {

            foreach($_POST['codes'] as $code){
                if(file_exists($code.".html")){
                    copy($tmp, $code.".html"); // 🔥 IMPORTANT FIX
                }
            }

            $_SESSION['msg'] = "🚀 Bulk Updated!";
        }
    }

    header("Location: index.php");
    exit;
}

// ================= BULK UPDATE =================
if(isset($_POST['bulk_update'])){
    if(isset($_POST['codes'])){
        foreach($_POST['codes'] as $code){
            move_uploaded_file($_FILES['bulk_file']['tmp_name'], $code.".html");
        }
        $_SESSION['msg'] = "🚀 Bulk Updated!";
    }

    header("Location: index.php");
    exit;
}
?>

<!DOCTYPE html>
<html>
<head>
<title>HTML Manager</title>
<style>
body{background:#000;color:#fff;font-family:Arial;text-align:center}
.box{background:#111;padding:20px;margin:20px auto;width:95%;max-width:1000px;border-radius:10px}
input,button{padding:10px;margin:5px;border-radius:5px;border:none}
button{background:#00ff99;cursor:pointer}
table{width:100%;border-collapse:collapse;margin-top:20px}
td{padding:10px;border-bottom:1px solid #333}
#toast{
position:fixed;bottom:20px;left:50%;
transform:translateX(-50%);
background:#00ff99;color:#000;
padding:10px;border-radius:5px;display:none;
}
</style>
</head>

<body>

<div class="box">
<h2>Upload HTML</h2>

<form method="POST" enctype="multipart/form-data">
<input type="file" name="file" required>
<button name="upload">Upload</button>
</form>

<p><?php echo $msg; ?></p>
<p>Total Files: <?php echo $count; ?></p>

<?php if($newLink!=""): ?>
<input type="text" value="<?php echo $newLink; ?>" id="linkBox" readonly>
<button onclick="copyLink()">Copy</button>
<?php endif; ?>
</div>

<div class="box">
<h2>All Files</h2>

<form method="POST" enctype="multipart/form-data">

<table>
<tr>
<td>Select</td>
<td>Code</td>
<td>Link</td>
<td>Actions</td>
</tr>

<?php foreach($files as $f):
$code = basename($f,".html");
$link = "https://".$_SERVER['HTTP_HOST']."/".$code;
?>

<tr>
<td><input type="checkbox" name="codes[]" value="<?php echo $code; ?>"></td>

<td><?php echo $code; ?></td>

<td>
<input type="text" value="<?php echo $link; ?>" readonly onclick="copyThis(this)">
</td>

<td>

<form method="POST" enctype="multipart/form-data" style="display:inline;">
<input type="hidden" name="code" value="<?php echo $code; ?>">
<input type="file" name="file" required>
<button name="update">Update</button>
</form>

<form method="POST" style="display:inline;">
<input type="hidden" name="code" value="<?php echo $code; ?>">
<button name="delete" style="background:red;color:#fff;">Delete</button>
</form>

</td>
</tr>

<?php endforeach; ?>
</table>

<br>

<h3>Bulk Action</h3>

<input type="file" name="bulk_file">
<br>
<button name="bulk_update">Bulk Update</button>
<button name="bulk_delete" style="background:red;color:#fff;">Bulk Delete</button>

</form>
</div>

<div id="toast">Copied!</div>

<script>
function copyLink(){
    var c=document.getElementById("linkBox");
    c.select();document.execCommand("copy");
    showToast("Copied!");
}
function copyThis(el){
    el.select();document.execCommand("copy");
    showToast("Copied!");
}
function showToast(msg){
    var t=document.getElementById("toast");
    t.innerText=msg;
    t.style.display="block";
    setTimeout(()=>{t.style.display="none";},1000);
}
</script>

</body>
</html>