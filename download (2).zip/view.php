<?php
if(isset($_GET['code'])){
    $file = $_GET['code'].".html";

    if(file_exists($file)){
        readfile($file); // 🔥 meta tag intact (Facebook preview OK)
        exit;
    } else {
        echo "❌ File Not Found!";
    }
}
?>